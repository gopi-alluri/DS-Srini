#understanding basic types
#types are inferred by runtime automatically

a = 10
print(a)
print(type(a))

b = 13.6
print(type(a))

c = 'abc'
print(type(a))

e = False 
print(a)
print(type(a))

